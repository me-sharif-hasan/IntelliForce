/*
 Copyright (c) 2019 Kevin Jones, All rights reserved.
 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
    derived from this software without specific prior written permission.
 */

package com.nawforce.runforce.ApexPages;

import com.nawforce.runforce.System.List;
import com.nawforce.runforce.System.PageReference;
import com.nawforce.runforce.System.SObject;
import com.nawforce.runforce.System.String;

@SuppressWarnings("unused")
public class KnowledgeArticleVersionStandardController {
	public KnowledgeArticleVersionStandardController(SObject sobject) {throw new java.lang.UnsupportedOperationException();}

	public void addFields(List<String> fieldNames) {throw new java.lang.UnsupportedOperationException();}
	public PageReference cancel() {throw new java.lang.UnsupportedOperationException();}
	public String getId() {throw new java.lang.UnsupportedOperationException();}
	public SObject getRecord() {throw new java.lang.UnsupportedOperationException();}
	public String getSourceId() {throw new java.lang.UnsupportedOperationException();}
	public void selectDataCategory(String categoryGroup, String category) {throw new java.lang.UnsupportedOperationException();}
	public PageReference view() {throw new java.lang.UnsupportedOperationException();}
}
